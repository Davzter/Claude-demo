---
title: "HTTP and Browser Fetchers API Reference"
description: "Look up Fetcher, AsyncFetcher, StealthyFetcher and session APIs. Check request options, browser settings and return types."
---

# Fetchers Classes

Here's the reference information for all fetcher-type classes' parameters, attributes, and methods.

You can import all of them directly like below:

```python
from scrapling.fetchers import (
    Fetcher, AsyncFetcher, StealthyFetcher,
    FetcherSession, AsyncStealthySession, StealthySession,
    RemoteSession, AsyncRemoteSession
)
```

## ::: scrapling.fetchers.Fetcher
    handler: python
    :docstring:

## ::: scrapling.fetchers.AsyncFetcher
    handler: python
    :docstring:

## ::: scrapling.fetchers.StealthyFetcher
    handler: python
    :docstring:


## Session Classes

### HTTP Sessions

## ::: scrapling.fetchers.FetcherSession
    handler: python
    :docstring:

### Stealth Sessions

## ::: scrapling.fetchers.StealthySession
    handler: python
    :docstring:

## ::: scrapling.fetchers.AsyncStealthySession
    handler: python
    :docstring:

### Remote Sessions {#remote-sessions}

## ::: scrapling.fetchers.RemoteSession
    handler: python
    :docstring:

## ::: scrapling.fetchers.AsyncRemoteSession
    handler: python
    :docstring:
